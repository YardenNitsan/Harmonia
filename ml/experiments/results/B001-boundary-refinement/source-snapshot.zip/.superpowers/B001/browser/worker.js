//#region packages/audio/fft.ts
/** In-place radix-2 FFT. Both arrays must have the same power-of-two length. */
function fft(real, imag) {
	const n = real.length;
	if (n < 2 || (n & n - 1) !== 0 || imag.length !== n) throw new Error("Invalid FFT size");
	for (let i = 1, j = 0; i < n; i++) {
		let bit = n >> 1;
		for (; j & bit; bit >>= 1) j ^= bit;
		j ^= bit;
		if (i < j) {
			[real[i], real[j]] = [real[j], real[i]];
			[imag[i], imag[j]] = [imag[j], imag[i]];
		}
	}
	for (let size = 2; size <= n; size *= 2) {
		const angle = -2 * Math.PI / size;
		const stepR = Math.cos(angle), stepI = Math.sin(angle);
		for (let start = 0; start < n; start += size) {
			let wr = 1, wi = 0;
			for (let j = 0; j < size / 2; j++) {
				const a = start + j, b = a + size / 2;
				const tr = wr * real[b] - wi * imag[b], ti = wr * imag[b] + wi * real[b];
				real[b] = real[a] - tr;
				imag[b] = imag[a] - ti;
				real[a] += tr;
				imag[a] += ti;
				const nextR = wr * stepR - wi * stepI;
				wi = wr * stepI + wi * stepR;
				wr = nextR;
			}
		}
	}
}
//#endregion
//#region packages/audio/features.ts
function normalize(values) {
	const norm = Math.sqrt(values.reduce((sum, value) => sum + value * value, 0));
	return norm > 0 ? values.map((value) => value / norm) : values;
}
function extractFeatures(samples, sampleRate, progress) {
	if (!Number.isFinite(sampleRate) || sampleRate < 8e3 || sampleRate > 192e3) throw new Error("Unsupported sample rate");
	if (samples.length === 0 || samples.length / sampleRate > 1200) throw new Error("Audio must be between one sample and 20 minutes");
	if (samples.some((sample) => !Number.isFinite(sample))) throw new Error("Invalid audio samples");
	const duration = samples.length / sampleRate;
	const size = 4096, hop = Math.max(1, Math.round(sampleRate * .02322));
	const window = Float64Array.from({ length: size }, (_, i) => .5 - .5 * Math.cos(2 * Math.PI * i / 4095));
	const real = new Float64Array(size), imag = new Float64Array(size), magnitude = new Float64Array(size / 2);
	const frames = [];
	let lastEnergy = 0;
	for (let center = 0; center < samples.length; center += hop) {
		let power = 0;
		for (let i = 0; i < size; i++) {
			const position = center + i - size / 2;
			const sample = position >= 0 && position < samples.length ? samples[position] : 0;
			real[i] = sample * window[i];
			imag[i] = 0;
			power += sample * sample;
		}
		fft(real, imag);
		let max = 0;
		for (let i = 0; i < magnitude.length; i++) {
			magnitude[i] = Math.hypot(real[i], imag[i]);
			max = Math.max(max, magnitude[i]);
		}
		const chroma = Array(12).fill(0), bass = Array(12).fill(0);
		for (let i = 2; i < magnitude.length - 1; i++) {
			if (magnitude[i] < max * .015 || magnitude[i] <= magnitude[i - 1] || magnitude[i] < magnitude[i + 1]) continue;
			const left = Math.log(magnitude[i - 1] + 1e-12), mid = Math.log(magnitude[i] + 1e-12), right = Math.log(magnitude[i + 1] + 1e-12);
			const offset = Math.max(-.5, Math.min(.5, .5 * (left - right) / (left - 2 * mid + right)));
			const frequency = (i + offset) * sampleRate / size;
			if (frequency < 45 || frequency > 2500) continue;
			const pitch = (Math.round(69 + 12 * Math.log2(frequency / 440)) % 12 + 12) % 12;
			const energy = Math.sqrt(magnitude[i] / Math.max(max, 1e-12));
			chroma[pitch] += energy;
			if (frequency < 260) bass[pitch] += energy * Math.pow(65 / frequency, .75);
		}
		const rms = Math.sqrt(power / size);
		frames.push({
			time: center / sampleRate,
			chroma: normalize(chroma),
			bass: normalize(bass),
			rms,
			onset: Math.max(0, rms - lastEnergy)
		});
		lastEnergy = rms;
		if (frames.length % 64 === 0) progress?.(center / samples.length);
	}
	const waveform = Array.from({ length: Math.min(900, samples.length) }, (_, bin) => {
		const begin = Math.floor(bin * samples.length / Math.min(900, samples.length));
		const end = Math.floor((bin + 1) * samples.length / Math.min(900, samples.length));
		let peak = 0;
		for (let i = begin; i < end; i++) peak = Math.max(peak, Math.abs(samples[i]));
		return Math.min(1, peak);
	});
	progress?.(1);
	return {
		frames,
		waveform,
		duration,
		hopSeconds: hop / sampleRate
	};
}
//#endregion
//#region packages/domain/chord.ts
var TRIADS = [
	"major",
	"minor",
	"diminished",
	"augmented",
	"sus2",
	"sus4",
	"power"
];
var EXTENSION_DEGREES = /* @__PURE__ */ new Set([
	6,
	9,
	11,
	13
]);
var TONE_DEGREES = /* @__PURE__ */ new Set([
	2,
	3,
	4,
	5,
	6,
	7,
	9,
	11,
	13
]);
var PITCH_PATTERN = /^([A-Ga-g])([#b]?)$/;
function modulo(value, modulus) {
	return (value % modulus + modulus) % modulus;
}
function notePitchClass(note) {
	const match = PITCH_PATTERN.exec(note);
	if (!match) throw new Error(`Invalid pitch name: ${note}`);
	const natural = {
		C: 0,
		D: 2,
		E: 4,
		F: 5,
		G: 7,
		A: 9,
		B: 11
	}[match[1].toUpperCase()];
	return modulo(natural + (match[2] === "#" ? 1 : match[2] === "b" ? -1 : 0), 12);
}
function uniqueSorted(values) {
	return [...new Set(values)].sort((left, right) => left - right);
}
function normalizeChord(chord) {
	if (chord.kind !== "chord") return { kind: chord.kind };
	const alterationKeys = /* @__PURE__ */ new Set();
	const alterations = chord.alterations.filter(({ degree, accidental }) => {
		const key = `${degree}:${accidental}`;
		if (alterationKeys.has(key)) return false;
		alterationKeys.add(key);
		return true;
	}).sort((left, right) => left.degree - right.degree || left.accidental - right.accidental).map((alteration) => ({ ...alteration }));
	return {
		...chord,
		root: modulo(chord.root, 12),
		extensions: uniqueSorted(chord.extensions),
		alterations,
		addedTones: uniqueSorted(chord.addedTones),
		omittedTones: uniqueSorted(chord.omittedTones),
		bass: chord.bass === null ? null : modulo(chord.bass, 12)
	};
}
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function assertExactKeys(value, keys, label) {
	const actual = Object.keys(value).sort();
	const expected = [...keys].sort();
	if (actual.length !== expected.length || actual.some((key, index) => key !== expected[index])) throw new Error(`${label} has invalid properties`);
}
function assertPitchClass(value, label) {
	if (!Number.isInteger(value) || value < 0 || value > 11) throw new Error(`${label} must be an integer pitch class from 0 to 11`);
}
function assertDegreeArray(value, allowed, label) {
	if (!Array.isArray(value) || value.some((degree) => !Number.isInteger(degree) || !allowed.has(degree))) throw new Error(`${label} contains an invalid degree`);
}
function validateChord(value) {
	if (!isRecord(value) || typeof value.kind !== "string") throw new Error("Chord must be an object with a kind");
	if (value.kind === "none" || value.kind === "unknown") {
		assertExactKeys(value, ["kind"], "Chord");
		return value;
	}
	if (value.kind !== "chord") throw new Error("Chord kind is invalid");
	assertExactKeys(value, [
		"kind",
		"root",
		"triad",
		"fifth",
		"seventh",
		"extensions",
		"alterations",
		"addedTones",
		"omittedTones",
		"bass",
		"spelling"
	], "Pitched chord");
	assertPitchClass(value.root, "Chord root");
	if (!TRIADS.includes(value.triad)) throw new Error("Chord triad is invalid");
	if (value.fifth !== -1 && value.fifth !== 0 && value.fifth !== 1) throw new Error("Chord fifth is invalid");
	if (value.seventh !== null && ![
		"minor",
		"major",
		"diminished"
	].includes(value.seventh)) throw new Error("Chord seventh is invalid");
	assertDegreeArray(value.extensions, EXTENSION_DEGREES, "Chord extensions");
	assertDegreeArray(value.addedTones, TONE_DEGREES, "Chord added tones");
	assertDegreeArray(value.omittedTones, TONE_DEGREES, "Chord omitted tones");
	if (!Array.isArray(value.alterations)) throw new Error("Chord alterations must be an array");
	for (const item of value.alterations) {
		if (!isRecord(item)) throw new Error("Chord alteration must be an object");
		assertExactKeys(item, ["degree", "accidental"], "Chord alteration");
		if (!Number.isInteger(item.degree) || !TONE_DEGREES.has(item.degree)) throw new Error("Chord alteration degree is invalid");
		if (![
			-2,
			-1,
			1,
			2
		].includes(item.accidental)) throw new Error("Chord alteration accidental is invalid");
	}
	if (value.bass !== null) assertPitchClass(value.bass, "Chord bass");
	if (value.spelling !== "sharp" && value.spelling !== "flat") throw new Error("Chord spelling is invalid");
	return value;
}
function makePitched(root, spelling) {
	return {
		kind: "chord",
		root,
		triad: "major",
		fifth: 0,
		seventh: null,
		extensions: [],
		alterations: [],
		addedTones: [],
		omittedTones: [],
		bass: null,
		spelling
	};
}
function extensionSet(highest) {
	if (highest === 9) return [9];
	if (highest === 11) return [9, 11];
	if (highest === 13) return [9, 13];
	return highest === 6 ? [6] : [];
}
function parseDegreeToken(token, chord) {
	const compact = token.trim().replace(/omit/i, "no");
	let match = /^(bb|##|b|#)(2|3|4|5|6|7|9|11|13)$/.exec(compact);
	if (match) {
		if (match[2] === "5" && (match[1] === "b" || match[1] === "#")) {
			chord.fifth = match[1] === "b" ? -1 : 1;
			return true;
		}
		chord.alterations.push({
			degree: Number(match[2]),
			accidental: match[1] === "bb" ? -2 : match[1] === "b" ? -1 : match[1] === "#" ? 1 : 2
		});
		return true;
	}
	match = /^add(2|3|4|5|6|7|9|11|13)$/i.exec(compact);
	if (match) {
		chord.addedTones.push(Number(match[1]));
		return true;
	}
	match = /^no(2|3|4|5|6|7|9|11|13)$/i.exec(compact);
	if (match) {
		chord.omittedTones.push(Number(match[1]));
		return true;
	}
	return false;
}
function parseChord(source) {
	if (typeof source !== "string") throw new Error("Chord symbol must be a string");
	const text = source.trim().replace(/♭/g, "b").replace(/♯/g, "#").replace(/Δ/g, "maj").replace(/°/g, "dim");
	if (/^(?:N|NC|N\.C\.|no\s*chord)$/i.test(text)) return { kind: "none" };
	if (/^(?:X|\?)$/i.test(text)) return { kind: "unknown" };
	const rootMatch = /^([A-Ga-g][#b]?)(.*)$/.exec(text);
	if (!rootMatch) throw new Error(`Invalid chord symbol: ${source}`);
	const rootName = rootMatch[1];
	let suffix = rootMatch[2];
	let bassName = null;
	const bassMatch = /\/([A-Ga-g][#b]?)$/.exec(suffix);
	if (bassMatch) {
		bassName = bassMatch[1];
		suffix = suffix.slice(0, bassMatch.index);
	} else if (suffix.includes("/")) throw new Error(`Invalid slash bass in chord: ${source}`);
	const spelling = rootName.includes("b") || bassName?.includes("b") ? "flat" : "sharp";
	const chord = makePitched(notePitchClass(rootName), spelling);
	chord.bass = bassName === null ? null : notePitchClass(bassName);
	suffix = suffix.replace(/\(([^()]*)\)/g, (_whole, contents) => {
		for (const token of contents.split(",")) if (!parseDegreeToken(token, chord)) throw new Error(`Invalid chord modifier: ${token}`);
		return "";
	});
	if (!/^(?:m7b5|ø7|hdim7)$/i.test(suffix)) suffix = suffix.replace(/(?:add|no|omit)(?:13|11|9|7|6|5|4|3|2)|(?:bb|##|b|#)(?:13|11|9|7|6|5|4|3|2)/gi, (token) => {
		if (!parseDegreeToken(token, chord)) throw new Error(`Invalid chord modifier: ${token}`);
		return "";
	});
	let qualityRemainder = suffix.toLowerCase();
	if (/^(?:m7b5|ø7|hdim7)$/.test(qualityRemainder)) {
		chord.triad = "minor";
		chord.fifth = -1;
		chord.seventh = "minor";
		qualityRemainder = "";
	} else if (qualityRemainder.startsWith("minmaj") || qualityRemainder.startsWith("mmaj")) {
		chord.triad = "minor";
		chord.seventh = "major";
		qualityRemainder = qualityRemainder.replace(/^(?:minmaj|mmaj)/, "");
	} else if (qualityRemainder.startsWith("maj")) {
		chord.triad = "major";
		chord.seventh = "major";
		qualityRemainder = qualityRemainder.slice(3);
	} else if (qualityRemainder.startsWith("min")) {
		chord.triad = "minor";
		qualityRemainder = qualityRemainder.slice(3);
	} else if (qualityRemainder.startsWith("m") && !qualityRemainder.startsWith("maj")) {
		chord.triad = "minor";
		qualityRemainder = qualityRemainder.slice(1);
	} else if (qualityRemainder.startsWith("-")) {
		chord.triad = "minor";
		qualityRemainder = qualityRemainder.slice(1);
	} else if (qualityRemainder.startsWith("dim")) {
		chord.triad = "diminished";
		qualityRemainder = qualityRemainder.slice(3);
	} else if (qualityRemainder.startsWith("aug")) {
		chord.triad = "augmented";
		qualityRemainder = qualityRemainder.slice(3);
	} else if (qualityRemainder.startsWith("+")) {
		chord.triad = "augmented";
		qualityRemainder = qualityRemainder.slice(1);
	}
	if (qualityRemainder.startsWith("maj")) {
		chord.seventh = "major";
		qualityRemainder = qualityRemainder.slice(3);
	}
	const susMatch = /sus(2|4)?/.exec(qualityRemainder);
	if (susMatch) {
		chord.triad = susMatch[1] === "2" ? "sus2" : "sus4";
		qualityRemainder = qualityRemainder.replace(susMatch[0], "");
	}
	if (qualityRemainder === "5" && chord.triad === "major" && chord.seventh === null) {
		chord.triad = "power";
		qualityRemainder = "";
	} else if (/^(6|7|9|11|13)$/.test(qualityRemainder)) {
		const degree = Number(qualityRemainder);
		if (degree === 6) chord.seventh = null;
		else if (chord.seventh === null) chord.seventh = chord.triad === "diminished" ? "diminished" : "minor";
		chord.extensions = extensionSet(degree);
		qualityRemainder = "";
	}
	if (qualityRemainder !== "") throw new Error(`Unsupported chord quality: ${source}`);
	return normalizeChord(chord);
}
function simpleDegree(degree) {
	return modulo(degree - 1, 7) + 1;
}
function degreeSemitones(degree) {
	return [
		0,
		2,
		4,
		5,
		7,
		9,
		11
	][simpleDegree(degree) - 1];
}
function chordTones(chord) {
	const tones = [{
		degree: 1,
		interval: 0
	}];
	tones.push(...{
		major: [[3, 4], [5, 7]],
		minor: [[3, 3], [5, 7]],
		diminished: [[3, 3], [5, 6]],
		augmented: [[3, 4], [5, 8]],
		sus2: [[2, 2], [5, 7]],
		sus4: [[4, 5], [5, 7]],
		power: [[5, 7]]
	}[chord.triad].map(([degree, interval]) => ({
		degree,
		interval
	})));
	if (chord.fifth !== 0) {
		const fifth = tones.find((tone) => tone.degree === 5);
		if (fifth) fifth.interval = 7 + chord.fifth;
		else tones.push({
			degree: 5,
			interval: 7 + chord.fifth
		});
	}
	if (chord.seventh !== null) tones.push({
		degree: 7,
		interval: chord.seventh === "minor" ? 10 : chord.seventh === "major" ? 11 : 9
	});
	for (const degree of [...chord.extensions, ...chord.addedTones]) tones.push({
		degree,
		interval: degreeSemitones(degree)
	});
	const replacedDegrees = new Set(chord.alterations.map(({ degree }) => simpleDegree(degree)));
	for (let index = tones.length - 1; index >= 0; index -= 1) if (tones[index].degree !== 1 && replacedDegrees.has(simpleDegree(tones[index].degree))) tones.splice(index, 1);
	for (const alteration of chord.alterations) tones.push({
		degree: alteration.degree,
		interval: degreeSemitones(alteration.degree) + alteration.accidental
	});
	for (const omitted of chord.omittedTones) {
		const degree = simpleDegree(omitted);
		for (let index = tones.length - 1; index >= 0; index -= 1) if (simpleDegree(tones[index].degree) === degree) tones.splice(index, 1);
	}
	return tones;
}
function chordPitchClasses(value) {
	const chord = validateChord(value);
	if (chord.kind !== "chord") return [];
	const pcs = chordTones(chord).map(({ interval }) => modulo(chord.root + interval, 12));
	if (chord.bass !== null) pcs.push(chord.bass);
	return uniqueSorted(pcs);
}
//#endregion
//#region packages/audio/recognizer.ts
var qualities = [
	"",
	"m",
	"5",
	"sus2",
	"sus4",
	"dim",
	"aug",
	"6",
	"m6",
	"7",
	"maj7",
	"m7",
	"mMaj7",
	"m7b5",
	"dim7",
	"add9",
	"madd9",
	"9",
	"maj9",
	"m9",
	"11",
	"13",
	"7b9",
	"7#9",
	"7#11",
	"7b13",
	"13sus4"
];
var roots = [
	"C",
	"C#",
	"D",
	"Eb",
	"E",
	"F",
	"F#",
	"G",
	"Ab",
	"A",
	"Bb",
	"B"
];
/** Acoustic template baseline. Scores are similarities, not calibrated probabilities. */
var TemplateRecognizer = class {
	version = "dsp-template-v1";
	templates = roots.flatMap((root) => qualities.map((quality) => {
		const chord = parseChord(root + quality);
		return {
			chord,
			pitches: chordPitchClasses(chord)
		};
	}));
	predict(frame) {
		if (frame.rms < .002 || frame.chroma.every((v) => v === 0)) return [{
			chord: { kind: "none" },
			score: 1
		}];
		const candidates = this.templates.map(({ chord, pitches }) => {
			const energy = pitches.reduce((sum, pitch) => sum + frame.chroma[pitch], 0) / Math.sqrt(pitches.length);
			const absent = pitches.reduce((sum, pitch) => sum + (frame.chroma[pitch] < .12 ? 1 : 0), 0);
			return {
				chord,
				score: Math.max(0, Math.min(1, energy - absent * .05 - Math.max(0, pitches.length - 3) * .008))
			};
		}).sort((a, b) => b.score - a.score).slice(0, 4);
		const bass = frame.bass.indexOf(Math.max(...frame.bass));
		return candidates.map((candidate) => {
			const notes = chordPitchClasses(candidate.chord);
			const inversion = frame.bass[bass] > .58 && bass !== candidate.chord.root && notes.includes(bass);
			return {
				...candidate,
				chord: {
					...candidate.chord,
					bass: inversion ? bass : null
				}
			};
		});
	}
};
function chordIdentity(chord) {
	if (chord.kind !== "chord") return chord.kind;
	return JSON.stringify([
		chord.root,
		chord.triad,
		chord.fifth,
		chord.seventh,
		chord.extensions,
		chord.alterations,
		chord.addedTones,
		chord.bass
	]);
}
//#endregion
//#region packages/audio/rhythm.ts
function estimateRhythm(features) {
	const { frames, hopSeconds, duration } = features;
	if (duration < 4) return {
		tempo: null,
		beats: []
	};
	const onset = frames.map((f) => f.onset);
	const total = onset.reduce((sum, v) => sum + v * v, 0);
	if (total < 1e-6) return {
		tempo: null,
		beats: []
	};
	let bestLag = 0, bestScore = 0;
	for (let lag = Math.floor(60 / 180 / hopSeconds); lag <= Math.ceil(60 / 55 / hopSeconds); lag++) {
		let score = 0;
		for (let i = lag; i < onset.length; i++) score += onset[i] * onset[i - lag];
		if (score > bestScore) {
			bestScore = score;
			bestLag = lag;
		}
	}
	if (bestScore / total < .08 || bestLag === 0) return {
		tempo: null,
		beats: []
	};
	let phase = 0, strength = 0;
	for (let offset = 0; offset < bestLag; offset++) {
		let sum = 0;
		for (let i = offset; i < onset.length; i += bestLag) sum += onset[i];
		if (sum > strength) {
			strength = sum;
			phase = offset;
		}
	}
	const beats = [];
	for (let t = phase * hopSeconds; t < duration; t += bestLag * hopSeconds) beats.push(t);
	return {
		tempo: 60 / (bestLag * hopSeconds),
		beats
	};
}
function estimateKey(features) {
	const mean = Array(12).fill(0);
	for (const frame of features.frames) frame.chroma.forEach((value, pitch) => {
		mean[pitch] += value;
	});
	if (mean.every((v) => v === 0)) return null;
	const profiles = {
		major: [
			6.35,
			2.23,
			3.48,
			2.33,
			4.38,
			4.09,
			2.52,
			5.19,
			2.39,
			3.66,
			2.29,
			2.88
		],
		minor: [
			6.33,
			2.68,
			3.52,
			5.38,
			2.6,
			3.53,
			2.54,
			4.75,
			3.98,
			2.69,
			3.34,
			3.17
		]
	};
	const centered = (values) => {
		const avg = values.reduce((a, b) => a + b, 0) / values.length;
		return values.map((v) => v - avg);
	};
	const chroma = centered(mean), norm = Math.hypot(...chroma);
	let best = {
		root: 0,
		mode: "major",
		score: 0
	};
	for (const mode of ["major", "minor"]) for (let root = 0; root < 12; root++) {
		const profile = centered(profiles[mode]);
		const score = chroma.reduce((sum, v, p) => sum + v * profile[(p - root + 12) % 12], 0) / (norm * Math.hypot(...profile) || 1);
		if (score > best.score) best = {
			root,
			mode,
			score
		};
	}
	return best;
}
//#endregion
//#region packages/audio/versions.ts
var PIPELINE_VERSION = "harmonia-worker-2";
//#endregion
//#region packages/audio/pipeline.ts
var NoveltyBoundaryDetector = class {
	detect(features) {
		const { frames } = features;
		return frames.map((frame, i) => {
			if (i === 0) return {
				time: 0,
				probability: 0
			};
			const before = frames[Math.max(0, i - 2)], after = frames[Math.min(frames.length - 1, i + 2)];
			if (before.rms < .002 && after.rms < .002) return {
				time: frame.time,
				probability: 0
			};
			const cosine = before.chroma.reduce((s, v, j) => s + v * after.chroma[j], 0);
			const silenceChange = before.rms < .002 !== after.rms < .002;
			return {
				time: frame.time,
				probability: silenceChange ? .95 : Math.max(0, Math.min(1, (1 - cosine) * 2.4))
			};
		});
	}
};
function analyzeFeatures(features, fingerprint, profile, progress, recognizer = new TemplateRecognizer()) {
	const boundaries = new NoveltyBoundaryDetector().detect(features);
	const predictions = [];
	for (let i = 0; i < features.frames.length; i++) {
		predictions.push(recognizer.predict(features.frames[i]));
		if (i % 128 === 0) progress?.("Recognizing chords and bass", .65 + .3 * i / features.frames.length);
	}
	const radius = profile === "fast" ? 2 : 4;
	const smoothed = predictions.map((choices, index) => {
		const votes = /* @__PURE__ */ new Map();
		for (let j = Math.max(0, index - radius); j <= Math.min(predictions.length - 1, index + radius); j++) {
			const candidate = predictions[j][0], key = chordIdentity(candidate.chord);
			const existing = votes.get(key);
			votes.set(key, {
				candidate,
				weight: (existing?.weight ?? 0) + candidate.score
			});
		}
		return [...votes.values()].sort((a, b) => b.weight - a.weight)[0]?.candidate ?? choices[0];
	});
	const segments = [];
	for (let i = 0; i < smoothed.length; i++) {
		const chosen = smoothed[i], previous = segments.at(-1);
		const end = i + 1 < features.frames.length ? features.frames[i + 1].time : features.duration;
		if (previous && chordIdentity(previous.chord) === chordIdentity(chosen.chord)) previous.end = end;
		else segments.push({
			id: `segment-${segments.length}`,
			start: features.frames[i].time,
			end,
			chord: chosen.chord,
			score: chosen.score,
			alternatives: predictions[i].filter((c) => chordIdentity(c.chord) !== chordIdentity(chosen.chord)).slice(0, 3)
		});
	}
	const rhythm = estimateRhythm(features);
	progress?.("Building the harmonic timeline", 1);
	return {
		id: `${fingerprint}:${recognizer.version}:${PIPELINE_VERSION}:${profile}`,
		fingerprint,
		profile,
		modelVersion: recognizer.version,
		pipelineVersion: PIPELINE_VERSION,
		duration: features.duration,
		segments,
		beats: rhythm.beats,
		tempo: rhythm.tempo,
		meter: null,
		key: estimateKey(features),
		waveform: features.waveform,
		boundaries,
		createdAt: (/* @__PURE__ */ new Date()).toISOString(),
		calibration: "uncalibrated",
		warnings: [
			"DSP baseline: similarity scores are not calibrated confidence. Dense mixes and extended chords need review.",
			"Beat and key estimates are provisional. Meter and downbeats are not inferred.",
			...profile === "accurate" ? ["Maximum accuracy model is not installed; this result uses the DSP baseline."] : []
		]
	};
}
//#endregion
//#region packages/audio/segmentation.ts
/** Offline candidate only. Changing these values requires a new comparison protocol. */
var REFINEMENT_SETTINGS = Object.freeze({
	candidateThreshold: .35,
	sustainedSeconds: .06,
	sustainedMargin: .05,
	timingSeconds: .05,
	timingFrames: 8
});
function requireInput(condition) {
	if (!condition) throw new Error("Invalid segmentation evidence");
}
function validateFeatures(features) {
	const { frames, duration } = features;
	requireInput(Number.isFinite(duration) && duration > 0 && duration <= 1200 && frames.length > 0 && frames.length <= 6e4 && frames[0].time === 0);
	frames.forEach((frame, index) => {
		requireInput(Number.isFinite(frame.time) && frame.time < duration && (index === 0 || frame.time > frames[index - 1].time) && Number.isFinite(frame.rms) && frame.rms >= 0 && Number.isFinite(frame.onset) && frame.onset >= 0);
		for (const vector of [frame.chroma, frame.bass]) requireInput(vector.length === 12 && vector.every((value) => Number.isFinite(value) && value >= 0 && value <= 1 + 1e-12));
	});
}
/** Same acoustic evidence as the existing DSP detector; deliberately not probabilities. */
function harmonicNovelty(features) {
	validateFeatures(features);
	const { frames } = features;
	return frames.map((_, index) => {
		if (index === 0) return 0;
		const before = frames[Math.max(0, index - 2)], after = frames[Math.min(frames.length - 1, index + 2)];
		if (before.rms < .002 && after.rms < .002) return 0;
		if (before.rms < .002 !== after.rms < .002) return .95;
		return Math.max(0, Math.min(1, (1 - before.chroma.reduce((sum, v, i) => sum + v * after.chroma[i], 0)) * 2.4));
	});
}
function canonicalKey(chord) {
	if (chord.kind !== "chord") return chord.kind;
	return JSON.stringify([
		chord.root,
		chord.triad,
		chord.fifth,
		chord.seventh,
		chord.extensions,
		chord.alterations,
		chord.addedTones,
		chord.omittedTones,
		chord.bass
	]);
}
function harmonicEvidence(predictions, count) {
	requireInput(predictions.length === count);
	return predictions.map((choices) => {
		requireInput(choices.length > 0 && choices.length <= 8);
		const normalized = choices.map((choice, index) => {
			requireInput(Number.isFinite(choice.score) && choice.score >= 0 && choice.score <= 1 && (index === 0 || choice.score <= choices[index - 1].score));
			const chord = choice.chord;
			if (chord.kind === "chord") for (const field of [
				chord.extensions,
				chord.alterations,
				chord.addedTones,
				chord.omittedTones
			]) requireInput(Array.isArray(field) && field.length <= 12);
			return normalizeChord(validateChord(chord));
		});
		return {
			chord: normalized[0],
			key: canonicalKey(normalized[0]),
			score: choices[0].score,
			margin: choices[0].score - (choices[1]?.score ?? 0)
		};
	});
}
function proposals(features, novelty) {
	const candidates = [];
	for (let first = 0; first < novelty.length;) {
		let end = first + 1;
		while (end < novelty.length && novelty[end] === novelty[first]) end++;
		if (first > 0 && novelty[first] >= REFINEMENT_SETTINGS.candidateThreshold && novelty[first] > novelty[first - 1] && (end === novelty.length || novelty[first] > novelty[end])) candidates.push({
			frameIndex: first,
			time: features.frames[first].time,
			score: novelty[first]
		});
		first = end;
	}
	return candidates;
}
function splitCuts(evidence, time) {
	const cuts = [];
	let previousSupported;
	for (let begin = 0; begin < evidence.length;) {
		let end = begin + 1;
		while (end < evidence.length && evidence[end].key === evidence[begin].key) end++;
		const duration = time(end) - time(begin);
		let margin = 0;
		for (let i = begin; i < end; i++) margin += evidence[i].margin * (time(i + 1) - time(i));
		if (duration + 1e-12 >= REFINEMENT_SETTINGS.sustainedSeconds && margin / duration + 1e-12 >= REFINEMENT_SETTINGS.sustainedMargin) {
			if (previousSupported !== void 0 && previousSupported !== evidence[begin].key) cuts.push(begin);
			previousSupported = evidence[begin].key;
		}
		begin = end;
	}
	return cuts;
}
function votesFor(begin, end, evidence, time) {
	const votes = /* @__PURE__ */ new Map();
	for (let i = begin; i < end; i++) {
		const frame = evidence[i], weight = frame.score * (time(i + 1) - time(i));
		const vote = votes.get(frame.key);
		if (vote) vote.weight += weight;
		else votes.set(frame.key, {
			key: frame.key,
			chord: frame.chord,
			weight
		});
	}
	const ranked = [];
	for (const vote of votes.values()) {
		const place = ranked.findIndex((other) => vote.weight > other.weight);
		ranked.splice(place < 0 ? ranked.length : place, 0, vote);
		if (ranked.length > 4) ranked.pop();
	}
	return ranked;
}
function refineTimes(cuts, time, novelty) {
	return cuts.map((frame, position) => {
		if (position === 0 || position === cuts.length - 1) return time(frame);
		const original = time(frame), lower = (time(cuts[position - 1]) + original) / 2, upper = (original + time(cuts[position + 1])) / 2;
		let best = frame;
		for (let i = Math.max(1, frame - REFINEMENT_SETTINGS.timingFrames); i <= Math.min(novelty.length - 1, frame + REFINEMENT_SETTINGS.timingFrames); i++) {
			const distance = Math.abs(time(i) - original), bestDistance = Math.abs(time(best) - original);
			if (distance > REFINEMENT_SETTINGS.timingSeconds + 1e-12 || time(i) <= lower || time(i) >= upper || novelty[i] <= novelty[frame]) continue;
			if (novelty[i] > novelty[best] || novelty[i] === novelty[best] && (distance < bestDistance - 1e-12 || Math.abs(distance - bestDistance) <= 1e-12 && i < best)) best = i;
		}
		return time(best);
	});
}
/** Pure offline comparison strategy. Production weighted stabilization is unchanged. */
function refineSegmentation(features, predictions, novelty = harmonicNovelty(features), options = {}) {
	validateFeatures(features);
	requireInput(novelty.length === features.frames.length && novelty.every((v) => Number.isFinite(v) && v >= 0 && v <= 1));
	const evidence = harmonicEvidence(predictions, features.frames.length);
	const time = (index) => index === evidence.length ? features.duration : features.frames[index].time;
	const candidates = proposals(features, novelty);
	const proposedCuts = [
		0,
		...candidates.map((candidate) => candidate.frameIndex),
		evidence.length
	];
	const candidateSegments = proposedCuts.slice(0, -1).map((frame, i) => ({
		start: time(frame),
		end: time(proposedCuts[i + 1])
	}));
	const proposed = new Set(proposedCuts);
	const insertedCuts = splitCuts(evidence, time).filter((frame) => !proposed.has(frame));
	const all = /* @__PURE__ */ new Set([...proposedCuts, ...insertedCuts]);
	const cuts = Array.from({ length: evidence.length + 1 }, (_, i) => i).filter((i) => all.has(i));
	const merged = [];
	const removedCuts = [];
	for (let i = 0; i < cuts.length - 1; i++) {
		const begin = cuts[i], end = cuts[i + 1], key = votesFor(begin, end, evidence, time)[0].key;
		const previous = merged.at(-1);
		if (previous?.key === key) {
			previous.end = end;
			removedCuts.push(begin);
		} else merged.push({
			begin,
			end,
			key
		});
	}
	const finalCuts = [...merged.map((interval) => interval.begin), evidence.length];
	const times = options.refineTiming === false ? finalCuts.map(time) : refineTimes(finalCuts, time, novelty);
	const timingMoves = finalCuts.flatMap((frame, i) => time(frame) === times[i] ? [] : [{
		from: time(frame),
		to: times[i]
	}]);
	return {
		segments: merged.map(({ begin, end }, i) => {
			const votes = votesFor(begin, end, evidence, time), duration = time(end) - time(begin);
			const alternatives = votes.map((vote) => ({
				chord: normalizeChord(vote.chord),
				score: Math.min(1, vote.weight / duration)
			}));
			requireInput(times[i + 1] > times[i]);
			return {
				id: `refined-${i}`,
				start: times[i],
				end: times[i + 1],
				...alternatives[0],
				alternatives: alternatives.slice(1)
			};
		}),
		candidates,
		candidateSegments,
		insertedCuts,
		removedCuts,
		timingMoves,
		calibration: "uncalibrated"
	};
}
//#endregion
//#region scripts/boundary-comparison-worker.ts
function freeze(value, seen = /* @__PURE__ */ new Set()) {
	if (!value || typeof value !== "object" || seen.has(value)) return;
	seen.add(value);
	for (const child of Object.values(value)) freeze(child, seen);
	Object.freeze(value);
}
async function hash(value) {
	const bytes = new TextEncoder().encode(JSON.stringify(value));
	return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes)), (b) => b.toString(16).padStart(2, "0")).join("");
}
var scope = self;
scope.onmessage = async (event) => {
	try {
		const { samples, fingerprint, warmup } = event.data;
		const started = performance.now();
		const features = extractFeatures(samples, 22050);
		const extracted = performance.now();
		const recognizer = new TemplateRecognizer();
		const predictions = features.frames.map((frame) => recognizer.predict(frame));
		const recognized = performance.now();
		freeze(features);
		freeze(predictions);
		const frameIndices = new Map(features.frames.map((frame, i) => [frame, i]));
		const retained = {
			version: recognizer.version,
			predict: (frame) => predictions[frameIndices.get(frame)]
		};
		const timings = {
			baseline_combined_assembly_ms: [],
			candidate_segmentation_ms: []
		};
		let baseline, candidate;
		for (let run = 0; run < (warmup ? 1 : 3); run++) {
			let clock = performance.now();
			const a = analyzeFeatures(features, fingerprint, "balanced", void 0, retained);
			timings.baseline_combined_assembly_ms.push(performance.now() - clock);
			clock = performance.now();
			const b = refineSegmentation(features, predictions);
			timings.candidate_segmentation_ms.push(performance.now() - clock);
			if (baseline && JSON.stringify(a.segments) !== JSON.stringify(baseline.segments)) throw new Error("Baseline changed across timing runs");
			if (candidate && JSON.stringify(b) !== JSON.stringify(candidate)) throw new Error("Candidate changed across timing runs");
			baseline = a;
			candidate = b;
		}
		const recomputed = analyzeFeatures(features, fingerprint, "balanced");
		if (JSON.stringify(recomputed.segments) !== JSON.stringify(baseline.segments)) throw new Error("Retained predictions changed baseline output");
		scope.postMessage({
			ok: true,
			frames: features.frames.length,
			duration: features.duration,
			feature_sha256: await hash(features),
			predictions_sha256: await hash(predictions),
			baseline_recomputation_matches: true,
			extraction_ms: extracted - started,
			recognition_ms: recognized - extracted,
			timings,
			baseline: baseline.segments,
			candidate: candidate.segments,
			provenance: {
				candidate_count: candidate.candidates.length,
				candidate_intervals: candidate.candidateSegments.length,
				inserted: candidate.insertedCuts,
				removed: candidate.removedCuts,
				timing_moves: candidate.timingMoves
			},
			worker_total_ms: performance.now() - started
		});
	} catch (error) {
		scope.postMessage({
			ok: false,
			error: String(error)
		});
	}
};
//#endregion
